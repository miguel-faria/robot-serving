from setuptools import setup

setup(name='promp',
      version='0.1',
      description='Package implementing promps',
      url='',
      author='Rui Silva',
      author_email='',
      license='MIT',
      packages=['promp', 'promp.utils'],
      zip_safe=False)
